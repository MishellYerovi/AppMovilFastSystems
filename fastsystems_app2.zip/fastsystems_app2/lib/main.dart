

import 'package:fastsystems_app2/webViewContainer.dart';
import 'package:flutter/material.dart';
import 'package:flutter_native_splash/flutter_native_splash.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:swipe_refresh/swipe_refresh.dart';

//final Uri _url = Uri.parse('https://flutter.dev');
//final Uri _url = Uri.parse('http://172.16.100.150/admin/login');

void main(){
  WidgetsBinding widgetsBinding = WidgetsFlutterBinding.ensureInitialized();
  FlutterNativeSplash.preserve(widgetsBinding: widgetsBinding);

  runApp(const MaterialApp(home: webViewFSContainer(), debugShowCheckedModeBanner: false,

  ));


  FlutterNativeSplash.remove();
}



class webViewFSContainer extends StatefulWidget{
  const webViewFSContainer({super.key});

  @override
  State<webViewFSContainer> createState() => _webViewFSContainerState();


}
final controller=WebViewController()
  ..setJavaScriptMode(JavaScriptMode.unrestricted)
  ..loadRequest(Uri.parse('http://172.16.100.150/admin/login'));

class _webViewFSContainerState  extends State <webViewFSContainer>{

  @override
  void initState() {
    super.initState();

  }

  @override
  Widget build(BuildContext context) {


    return Scaffold(

      appBar: AppBar(
        toolbarHeight: 0,

        elevation: 5,
        shadowColor: Colors.lightBlueAccent,
        backgroundColor: Colors.blue,

      ),
      body:  WebViewWidget(controller: controller),


    );
    throw UnimplementedError();
  }
}










